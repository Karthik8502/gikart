card.style.display = match ? 'block' : 'none';
